from django.apps import AppConfig


class MusiciantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'musiciant'
